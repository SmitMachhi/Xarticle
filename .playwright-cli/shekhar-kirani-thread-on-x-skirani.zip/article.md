# Shekhar Kirani thread on X

- author: Shekhar Kirani (@skirani)
- source_url: https://x.com/skirani/status/2025978884970398025
- extracted_at: 2026-02-27T01:54:03.291Z
- extraction_provider: fxtwitter
- published_at: 2026-02-23T16:59:41.000Z

## metrics

- likes: 187
- replies: 18
- reposts: 12
- views: 35727
- bookmarks: 323

## extraction_notes

- Auto-detected thread: 7 posts merged. Metrics shown are from the root post.
- Extracted via public status parser.
- Thread resolved via Thread Reader fallback (7 posts).

## content

## Post 1

The most underrated AI opportunity for startups: automating how companies talk to each other. Within a company, AI is making rapid progress. But across companies? The world still runs on emails, phone calls, PDFs, and FTP. A thread 🧵

## Post 2

Procurement example A procurement team emails a vendor. Vendor sends back a PDF quote. Someone manually enters it into an ERP. Approval goes out via email. PO gets generated. Another PDF. Every step - a human in the middle.

## Post 3

Food supply chain example Or how food gets to a restaurant: Restaurant calls a distributor. Distributor checks inventory over email with the warehouse. Warehouse coordinates with multiple next-level distributors over WhatsApp and phone calls. Invoices are PDFs. Delivery confirmations are text messages.

## Post 4

Why hard Why has this barely been touched by AI? No shared systems - every company has its own stack No APIs between most businesses - the "API" is email and PDFs Trust and compliance - automating across boundaries requires a different level of verification

## Post 5

Why is this valuable? Because this is where the most time and effort are wasted. Every manual handoff between companies is a delay, an error, and a cost. AI that can read, understand, and act on emails, voice calls, and documents across company boundaries - a massive unlock.

## Post 6

Portfolio examples We are already seeing this happen: @FinrepAI - automating reporting between the CFO office and SEC. @nanonets - deploying AI workflows at the edge of large orgs, spanning systems never designed to talk to each other

## Post 7

The companies solving this will not be building another internal copilot. They will be building the connective tissue of business. If you are pursuing such use cases with AI, I would love to hear about it.
